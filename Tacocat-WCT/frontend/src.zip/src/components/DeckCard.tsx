import { useEffect, useState } from "react";
import Spinner from './Spinner';
import { simpleAction, connectWallet, spinnerShow, buyToken, addToken } from "../store/actions/wallet"
import { connect, useDispatch } from "react-redux";

interface DeckCardProps {
  deckId: number;
  simple?: any
  connectWallet?: any
  buyToken?: any
};

const DECK_INFO = [
  {
    name: 'WhiteList',
    price: '100 USDT',
    text: 'The members of WhiteList can buy WCT tokens - 250,000 per 100 USDT.',
  },
  {
    name: 'Billionaries',
    price: '1000 USDT',
    text: 'The billionaries can buy WCT tokens - 250,000 per 1000USDT.',
  },
  {
    name: 'Decks',
    price: '100 USDT',
    text: 'The clients who have decks can by tokens - 250,000 per 100 USDT',
  },
  {
    name: 'Mid-Range',
    price: '250,000 per 100 USDT',
    text: 'Featuring Duckox, an amplified quacking duck filled with rage that blares through the speakers, this deck is all about balance through the beginning rounds, by creating a balanced defensive and aggressive stance, while building towards powerful Nemots for the finish.{nl}To win with this deck, maintain good pressure early while collecting late-game Nemots that can wipe the field easily.',
  },
  {
    name: 'Utility',
    price: '250,000 per 100 USDT',
    text: 'Featuring TVeleon, a TV-Chameleon hybrid that, like all good TV, blends into the background of any situation and can stupefy enemy Nemots temporarily, this deck is mostly made of Nemots and spells designed to be useful on their own or in combinations with other decks.{nl}The key to winning with this deck is through blending in other Nemots and spells to it, creating a shocking new unexpected deck!',
  }
];

const DeckCard = ({ deckId, simple}: DeckCardProps) => {
  const [showModal, setShowModal] = useState(false);
  const dispatch = useDispatch();

  const handleOpenModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };
  
  useEffect(()=>{
    console.log("Deck: ", buyToken);
  }, [simple])

  const replaceMacros = (text: string): string => {
    return text
      .replaceAll('{nl}', '\r\n\r\n');
  };

  return (
    <>
      {showModal && (
        <div
          className="z-40 fixed top-0 left-0 w-screen h-screen bg-black bg-opacity-60 flex flex-col md:flex-row items-center justify-center"
          style={{
            backdropFilter: 'blur(10px)'
          }}
        >
          <button
            className="absolute top-18 left-10 rounded-full bg-white text-black flex items-center justify-center w-10 h-10 hover:bg-gray-400"
            onClick={() => handleCloseModal()}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>

          <div
            className="bg-contain bg-center bg-no-repeat w-full max-w-3/4 h-3/4 mt-25 md:(w-1/3 h-full max-h-3/4)"
            style={{
              backgroundImage: `url(${simple.imagePath[deckId]})`
            }}
          />

          <div className="flex flex-col justify-center p-8 gap-8 md:(w-1/2 h-full)">
            <h1 className="text-[#4dff55] text-5xl">{DECK_INFO[deckId].name} Deck</h1>
            <p className="max-w-screen-lg text-md text-[#ffe41e] whitespace-pre-line">
              {replaceMacros(DECK_INFO[deckId].text)}
            </p>
          </div>
        </div>
      )}

      <div
        className="relative rounded-lg flex flex-col h-auto border-[#ffe41e] border-3 shadow-lg p-5 w-52 gap-2 bg-center"
        style={{
          position: 'relative',
          backgroundImage: `url(${simple.imagePath[deckId]})`,
          backgroundSize: '170% 170%'
        }}
      >
        <div
          className="absolute top-0 left-0 w-full h-1/3 flex flex-col gap-1 bg-gradient-to-b from-black to-transparent text-[#4dff55] flex items-center justify-center text-2xl rounded-md"
          style={{
            textShadow: '2px 2px 5px black'
          }}
        >
          <span>{DECK_INFO[deckId].name}</span>
          <span className="text-sm text-white">{DECK_INFO[deckId].price}</span>
        </div>

        <div className="h-[168px] w-[168px]"/>

        {simple.connectState && (
          <div className="relative">
            {deckId === 0 && (<input type="number" className="absolute bottom-10 mb-2 focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-2 pr-2 border-gray-300 rounded-md"/>)}
            <button
              className="rounded font-bold bg-[#f9069c] shadow-md py-2 px-4 text-gray-800 hover:(text-white bg-[#970960]) "
              onClick={() => {
                simple.balanceCond[deckId] ? dispatch(buyToken(deckId, simple)) : dispatch(addToken(deckId))}}
            >
              {simple.balanceCond[deckId] ? "Buy" : "Owned"}
            </button>
          </div>
        )}

        <button
          className="rounded font-bold bg-[#4dff55] shadow-md py-2 px-4 text-gray-800 hover:(text-white bg-[#239728]) "
          onClick={() => handleOpenModal()}
        >
          Contents
        </button>
      </div>

      <Spinner spinnerShow={simple.show} message={simple.message} />
    </>
  );
};

const mapStateToProps = (state: any) =>{
  return { ...state }
}

const mapDispatchToProps = () => {
  return {
    simpleAction: simpleAction,
    connectWallet: connectWallet,
    spinnerShow: spinnerShow,
    buyToken: buyToken,
    addToken: addToken
  }
}

 export default connect(mapStateToProps, mapDispatchToProps)(DeckCard);
