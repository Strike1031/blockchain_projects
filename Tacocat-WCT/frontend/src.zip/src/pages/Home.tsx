import Navbar from '../components/Navbar';
import DeckCard from '../components/DeckCard';
import { useEffect } from 'react';
import '../css/styles.css';
import { simpleAction, connectWallet, spinnerShow, disconnectWallet, buyToken, addToken } from "../store/actions/wallet";
import { connect, useDispatch } from "react-redux";
import ReactTooltip from "react-tooltip";

const Home = (simple: any) => {
  const dispatch = useDispatch();

  useEffect(()=>{
    console.log("Home: ", simple)
  }, [simple])

  return (
    <>
      <div
        style={{
          fontFamily: 'PixelSplitter'
        }}
      >
        {/* Navbar */}
        <Navbar />

        {/* Connect Button */}
        <div className="z-50 fixed top-1 md:right-0 items-center justify-start flex py-2 px-4">
          <button
              className="font-bold ml-auto bg-[#4dff55] md:flex shadow-md py-2 px-4 text-[#f9069c] hover:(text-white bg-[#239728])"
              onClick={() => { 
                simple.connectState ? dispatch(simple.disconnectWallet()) : dispatch(simple.connectWallet())
               }}
            >
              {simple.connectBtnName}
          </button>
        </div>
        
        {/* Decks */}
        <div
          id="decks"
          className="flex flex-col mt-28 px-8 gap-4 items-center justify-center md:(flex-row gap-8) "
        >
          <DeckCard deckId={0} />
          <DeckCard deckId={1} />
          <DeckCard deckId={2} />
          {/* <DeckCard deckId={3} />
          <DeckCard deckId={4} /> */}
        </div>

        {/* Locked Balance Info */}
        <div
          className="h-auto flex-col mt-28 mx-auto gap-4 items-center justify-center md:w-1/2 md:(flex-row gap-8) text-[#ffe41e] border-[#ffe41e] border-3 rounded-lg bg-center p-3"
          style={{
            position: 'relative',
            backgroundSize: '170% 170%',
            // margin: 'auto'
          }}
        >
          <div className='text-xs md:text-lg'>
            Total : <span className="text-[#4dff55]">{simple.totalAirdrop}</span> WCT
          </div>
          <div className='text-xs md:text-lg flex'>
            <div className='md:w-1/2'>
              Locked : <span className="text-[#4dff55]">{simple.lockAmount}</span>
            </div>
            <div className='md:w-1/2'>
              Unlocked : <span className="text-[#4dff55]">{simple.unlockAmount}</span>
            </div>
          </div>
          <div className='text-xs md:text-lg'>
            Unlock Available: <span className="text-[#4dff55]">{simple.unlockAvail}</span> WCT
          </div>
          <div className='text-xs md:text-lg flex'>
            <div className='md:w-2/3 pt-2'>
              Next Unlock Time: <span className='text-[#4dff55]'>{simple.unlockTime}</span>
            </div>
            <div className='md:w-1/3'>
            <button
              className="rounded font-bold bg-[#4dff55] shadow-md py-2 px-4 text-gray-800 hover:(text-white bg-[#239728]) "
            >
              Unlock
            </button>
            </div>
          </div>
        </div>

        {/* More Info */}
        <div
          id="more-info"
          className="flex flex-col mt-16 px-8 pb-16 gap-8 items-center justify-center"
        >
          <h1 className="text-[#4dff55] text-5xl">WildCash Token Presale</h1>
          <p className="w-full md:max-w-screen-lg text-md text-[#ffe41e]">
          Welcome to the presale of the Token for the Wildcash.
            <br /> <br />
            You have a chance to grab some extra goodies and perks by buying presale!
            <br /><br />
            For a limited time, get 30 cards for the price of 20! At official launch, starting decks will consist of 20 random cards. Buying a presale deck right now will give you the following powerful cards: 14 Nemots, 15 Spell cards and 1 Overpower (Player effect) card.
            <br /><br />
            Because we are offering a lot of extras, you are only allowed to buy 1 deck of each kind per wallet! This includes Aggro, Control, Combo, Mid-Range and Utility decks. All decks will cost 30 USDT (BEP20) and will be stored in your wallet, whether it is Metamask, Atomic or any other wallet you use.
            <br /><br />
            Want to get whitelisted for the Wildcard launch? Crypto gaming is coming to the masses and the smart people are getting in early.  Each starter deck purchase during this period will be whitelisted to purchase $100 of Wildcard Token, during the initial token offering on February 23rd! This whitelist spot offers you a hefty discount of 50% of the public launch price.
            <br /><br />
            Join the presale for Wildcard Starter Decks now. You will be helping Tacocat and the development of the Wildcard project tremendously by buying early, while gaining unique advantages with extra cards and a whitelisting opportunity. Be ahead of the crowd and take advantage of this special offer while it lasts.
            <br /><br />
            <span className="text-[#4dff55]">The contract address to add to your wallet to see the token is:</span>
            <br /><br />
            WCT and 18 digits
            <br />
            <span className="text-[#f9069c] text-xs md:text-lg">0x06D8e34c4D2eA294cBEBF8F459a9687EBeb80aa0</span>
            {simple.connectState && ( 
            <button data-tip data-for="wasToken"
              className="font-bold shadow-md py-2 px-4 text-[#cccccc] hover:(text-white)"
              onClick={() => { 
                dispatch(simple.addToken(0));
              }}
            >
              +
              <ReactTooltip id="wasToken" place="right" type="warning" effect="float">
                Add to Wallet
              </ReactTooltip>
            </button>)}
          </p>
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state: any) =>{
  state = state.simple;
  return { ...state }
}

const mapDispatchToProps = () => {
  return {
    simpleAction: simpleAction,
    connectWallet: connectWallet,
    disconnectWallet: disconnectWallet,
    spinnerShow: spinnerShow,
    buyToken: buyToken,
    addToken: addToken
  }
}

 export default connect(mapStateToProps, mapDispatchToProps)(Home);
