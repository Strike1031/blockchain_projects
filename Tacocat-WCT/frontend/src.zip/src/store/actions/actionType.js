export const CONNECT_WALLET = "CONNECT_WALLET";
export const DISCONNECT_WALLET = "DISCONNECT_WALLET";
export const SPINNER_SHOW = "spinner_show";
export const SPINNER_TEXT = "spinner_text";
export const BUY_TOKEN = "buy_token";
export const ADD_TOKEN = "add_token";