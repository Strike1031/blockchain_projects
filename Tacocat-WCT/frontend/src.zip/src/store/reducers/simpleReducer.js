import Web3 from "web3";
import { BUY_TOKEN, CONNECT_WALLET, DISCONNECT_WALLET, SPINNER_SHOW, ADD_TOKEN } from "../actions/actionType";

import CRABALL_IMAGE from '../../images/craball.png';
import PIGANDY_IMAGE from '../../images/pigandy.png';
import CLOCKKEN_IMAGE from '../../images/clockken.png';
import DUCKOX_IMAGE from '../../images/duckox.png';
import TVELEON_IMAGE from '../../images/tveleon.png';

const initialState = {
  // Connect Wallet
  deckId: [0, 1, 2, 3, 4],
  account: "",
  connectState: false,
  connectBtnName: "Connect Wallet",
  balanceCond: [false, false, false, false, false],
  web3: Web3,
  imagePath: [
    CRABALL_IMAGE, CLOCKKEN_IMAGE, PIGANDY_IMAGE, DUCKOX_IMAGE, TVELEON_IMAGE
  ],
  //spinner
  show: false,
  message: "",
  totalAirdrop: "-",
  unlockAmount: "-",
  lockAmount: "-",
  unlockAvail: "-",
  unlockTime: "-",
}

const simpleReducer = (state = initialState, action) => {
  switch (action.type) {
    case SPINNER_SHOW:
      return {
        ...state,
        show: action.payload.show,
        message: action.payload.message
      }
    case CONNECT_WALLET:
      return {
        ...state,
        account: action.payload.account,
        connectState: true,
        connectBtnName: action.payload.connectBtnName,
        balanceCond: action.payload.balanceCond,
        web3: action.payload.web3,
        totalAirdrop: action.payload.totalAirdrop,
        unlockAmount: action.payload.unlockAmount,
        lockAmount: action.payload.lockAmount,
        unlockAvail: action.payload.unlockAvail, 
        unlockTime: action.payload.unlockTime,
      }
    case DISCONNECT_WALLET:
      return {
        ...state,
        connectState: action.payload.connectState,
        connectBtnName: action.payload.connectBtnName
      }
    case BUY_TOKEN:
      return {
        ...state,
        balanceCond: action.payload.balanceCond,
        connectState: action.payload.connectState,
      }
    case ADD_TOKEN:
    default:
      return state
    }
  }


export default simpleReducer;