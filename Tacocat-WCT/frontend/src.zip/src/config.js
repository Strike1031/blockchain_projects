// env_mode: true-- production mode, false-- development mode

export const ENV_MODE = false;